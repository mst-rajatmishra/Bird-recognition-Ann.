wget https://box.tu-chemnitz.de/index.php/s/iPUsAA94KPtWaVf/download -O birdCLEF_TUCMI_Run1_Model.pkl
